﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//biblioteca dos campos  do menu
using UnityEngine.UI;

public class Dados : MonoBehaviour {

    public InputField txtNome;
    public string []vetorNomes;
    public int tamanho = 5;
    public int contador = 0;

    public Text todosOsNomes;

	void Start () {
        //inicializa o vetor passando o tamanho
        vetorNomes = new string[tamanho];	
	}
    //método que insere os nomes
    public void guardaNomes()
    {
        if (contador < tamanho)
        {
            vetorNomes[contador] = txtNome.text;
            txtNome.text = string.Empty;
            print(vetorNomes[contador]);            
            contador = contador + 1;
        }
        else
        {
            print("Vetor cheio!");
        }
    }


    //método para exibir os nomes do vetor
    public void mostraNomes()
    {
        todosOsNomes.text = string.Empty;
        int x = 0;
        while (x < contador)
        {
            todosOsNomes.text += vetorNomes[x] + "\n";
            x = x + 1;
        }
    }

    //método que remove nome do vetor
    public void removeNome()
    {
        if (contador > 0)
        {
            contador = contador - 1;
            vetorNomes[contador] = string.Empty;
            this.mostraNomes();         
        }
        else
        {
            print("Vetor vazio!");
        }
    }


	void Update () {
		
	}
}
